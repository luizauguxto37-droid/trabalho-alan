"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Calendar, Users, CreditCard, User, Plus, Minus } from "lucide-react"

interface BookingFormProps {
  packageData: {
    id: number
    name: string
    price: number
    duration_days: number
    destination_name: string
    max_people: number
  }
}

interface Passenger {
  name: string
  cpf: string
  birth_date: string
  passport: string
}

export function BookingForm({ packageData }: BookingFormProps) {
  const [formData, setFormData] = useState({
    travel_date: "",
    num_people: 1,
    special_requests: "",
  })

  const [passengers, setPassengers] = useState<Passenger[]>([{ name: "", cpf: "", birth_date: "", passport: "" }])

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price)
  }

  const totalPrice = packageData.price * formData.num_people

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    setSuccess("")

    // Validar se todos os passageiros foram preenchidos
    const validPassengers = passengers.slice(0, formData.num_people)
    for (let i = 0; i < validPassengers.length; i++) {
      const passenger = validPassengers[i]
      if (!passenger.name || !passenger.cpf || !passenger.birth_date) {
        setError(`Preencha todos os dados obrigatórios do passageiro ${i + 1}`)
        setLoading(false)
        return
      }
    }

    try {
      const response = await fetch("/api/bookings.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": "csrf_token_here", // Implementar token CSRF real
        },
        body: JSON.stringify({
          ...formData,
          package_id: packageData.id,
          passengers: validPassengers,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setSuccess("Reserva criada com sucesso! Você será redirecionado para o pagamento.")
        // Redirecionar para página de pagamento
        setTimeout(() => {
          window.location.href = `/booking/${result.booking_id}/payment`
        }, 2000)
      } else {
        setError(result.message)
      }
    } catch (err) {
      setError("Erro ao processar reserva. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    if (name === "num_people") {
      const numPeople = Number.parseInt(value)
      setFormData((prev) => ({ ...prev, [name]: numPeople }))

      // Ajustar array de passageiros
      const newPassengers = [...passengers]
      while (newPassengers.length < numPeople) {
        newPassengers.push({ name: "", cpf: "", birth_date: "", passport: "" })
      }
      setPassengers(newPassengers)
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }))
    }
  }

  const handlePassengerChange = (index: number, field: keyof Passenger, value: string) => {
    const newPassengers = [...passengers]
    newPassengers[index] = { ...newPassengers[index], [field]: value }
    setPassengers(newPassengers)
  }

  const adjustPeople = (increment: boolean) => {
    const newNum = increment ? formData.num_people + 1 : formData.num_people - 1
    if (newNum >= 1 && newNum <= packageData.max_people) {
      setFormData((prev) => ({ ...prev, num_people: newNum }))

      const newPassengers = [...passengers]
      if (increment) {
        newPassengers.push({ name: "", cpf: "", birth_date: "", passport: "" })
      }
      setPassengers(newPassengers)
    }
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Package Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CreditCard className="h-5 w-5 mr-2" />
            Resumo da Reserva
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-lg">{packageData.name}</h3>
                <p className="text-muted-foreground">{packageData.destination_name}</p>
                <Badge variant="secondary">{packageData.duration_days} dias</Badge>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Preço por pessoa</p>
                <p className="text-xl font-bold text-primary">{formatPrice(packageData.price)}</p>
              </div>
            </div>

            <Separator />

            <div className="flex justify-between items-center">
              <span className="font-semibold">
                Total ({formData.num_people} pessoa{formData.num_people > 1 ? "s" : ""})
              </span>
              <span className="text-2xl font-bold text-primary">{formatPrice(totalPrice)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-emerald-200 bg-emerald-50 text-emerald-800">
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        {/* Booking Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Detalhes da Viagem
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="travel_date">Data da Viagem *</Label>
                <Input
                  id="travel_date"
                  name="travel_date"
                  type="date"
                  value={formData.travel_date}
                  onChange={handleChange}
                  min={new Date().toISOString().split("T")[0]}
                  required
                />
              </div>

              <div>
                <Label htmlFor="num_people">Número de Pessoas *</Label>
                <div className="flex items-center space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => adjustPeople(false)}
                    disabled={formData.num_people <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <Input
                    id="num_people"
                    name="num_people"
                    type="number"
                    value={formData.num_people}
                    onChange={handleChange}
                    min="1"
                    max={packageData.max_people}
                    className="text-center"
                    required
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => adjustPeople(true)}
                    disabled={formData.num_people >= packageData.max_people}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-1">Máximo: {packageData.max_people} pessoas</p>
              </div>
            </div>

            <div>
              <Label htmlFor="special_requests">Solicitações Especiais</Label>
              <Textarea
                id="special_requests"
                name="special_requests"
                placeholder="Alguma solicitação especial? (opcional)"
                value={formData.special_requests}
                onChange={handleChange}
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Passengers Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Dados dos Passageiros
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {passengers.slice(0, formData.num_people).map((passenger, index) => (
              <div key={index} className="space-y-4 p-4 border rounded-lg">
                <h4 className="font-semibold flex items-center">
                  <User className="h-4 w-4 mr-2" />
                  Passageiro {index + 1}
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor={`passenger_name_${index}`}>Nome Completo *</Label>
                    <Input
                      id={`passenger_name_${index}`}
                      type="text"
                      placeholder="Nome completo"
                      value={passenger.name}
                      onChange={(e) => handlePassengerChange(index, "name", e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor={`passenger_cpf_${index}`}>CPF *</Label>
                    <Input
                      id={`passenger_cpf_${index}`}
                      type="text"
                      placeholder="000.000.000-00"
                      value={passenger.cpf}
                      onChange={(e) => handlePassengerChange(index, "cpf", e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor={`passenger_birth_date_${index}`}>Data de Nascimento *</Label>
                    <Input
                      id={`passenger_birth_date_${index}`}
                      type="date"
                      value={passenger.birth_date}
                      onChange={(e) => handlePassengerChange(index, "birth_date", e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor={`passenger_passport_${index}`}>Passaporte</Label>
                    <Input
                      id={`passenger_passport_${index}`}
                      type="text"
                      placeholder="Número do passaporte (se aplicável)"
                      value={passenger.passport}
                      onChange={(e) => handlePassengerChange(index, "passport", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Button type="submit" size="lg" className="w-full" disabled={loading}>
          {loading ? "Processando..." : `Reservar por ${formatPrice(totalPrice)}`}
        </Button>
      </form>
    </div>
  )
}
