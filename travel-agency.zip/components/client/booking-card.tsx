import Image from "next/image"
import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Calendar, MapPin, Users, Star, Eye, Download } from "lucide-react"

interface BookingCardProps {
  booking: {
    id: number
    package_name: string
    destination_name: string
    city: string
    country: string
    travel_date: string
    num_people: number
    total_price: number
    status: string
    payment_status: string
    image_url: string
    created_at: string
  }
}

export function BookingCard({ booking }: BookingCardProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      pending: { label: "Pendente", variant: "secondary" as const },
      confirmed: { label: "Confirmada", variant: "default" as const },
      cancelled: { label: "Cancelada", variant: "destructive" as const },
      completed: { label: "Concluída", variant: "outline" as const },
    }

    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.pending
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>
  }

  const getPaymentBadge = (status: string) => {
    const statusMap = {
      pending: { label: "Pendente", variant: "secondary" as const },
      paid: { label: "Pago", variant: "default" as const },
      refunded: { label: "Reembolsado", variant: "outline" as const },
    }

    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.pending
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>
  }

  const canCancel = booking.status === "pending" || booking.status === "confirmed"
  const canReview = booking.status === "completed"

  return (
    <Card className="overflow-hidden">
      <div className="flex flex-col md:flex-row">
        {/* Image */}
        <div className="relative h-48 md:h-auto md:w-48 flex-shrink-0">
          <Image
            src={booking.image_url || "/placeholder.svg"}
            alt={booking.package_name}
            fill
            className="object-cover"
          />
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col">
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
              <div>
                <h3 className="font-semibold text-lg">{booking.package_name}</h3>
                <div className="flex items-center text-muted-foreground text-sm">
                  <MapPin className="h-4 w-4 mr-1" />
                  {booking.city}, {booking.country}
                </div>
              </div>
              <div className="flex flex-col sm:items-end gap-2">
                {getStatusBadge(booking.status)}
                {getPaymentBadge(booking.payment_status)}
              </div>
            </div>
          </CardHeader>

          <CardContent className="flex-1 pb-3">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <div className="flex items-center text-muted-foreground mb-1">
                  <Calendar className="h-4 w-4 mr-1" />
                  Data da Viagem
                </div>
                <p className="font-medium">{formatDate(booking.travel_date)}</p>
              </div>

              <div>
                <div className="flex items-center text-muted-foreground mb-1">
                  <Users className="h-4 w-4 mr-1" />
                  Pessoas
                </div>
                <p className="font-medium">{booking.num_people}</p>
              </div>

              <div>
                <div className="text-muted-foreground mb-1">Valor Total</div>
                <p className="font-medium text-primary">{formatPrice(booking.total_price)}</p>
              </div>

              <div>
                <div className="text-muted-foreground mb-1">Reservado em</div>
                <p className="font-medium">{formatDate(booking.created_at)}</p>
              </div>
            </div>
          </CardContent>

          <Separator />

          <CardFooter className="pt-3">
            <div className="flex flex-wrap gap-2 w-full">
              <Button variant="outline" size="sm" asChild>
                <Link href={`/dashboard/bookings/${booking.id}`}>
                  <Eye className="h-4 w-4 mr-2" />
                  Ver Detalhes
                </Link>
              </Button>

              {booking.payment_status === "paid" && (
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Voucher
                </Button>
              )}

              {canReview && (
                <Button variant="outline" size="sm" asChild>
                  <Link href={`/dashboard/reviews/new?booking=${booking.id}`}>
                    <Star className="h-4 w-4 mr-2" />
                    Avaliar
                  </Link>
                </Button>
              )}

              {canCancel && (
                <Button variant="destructive" size="sm" className="ml-auto">
                  Cancelar
                </Button>
              )}
            </div>
          </CardFooter>
        </div>
      </div>
    </Card>
  )
}
