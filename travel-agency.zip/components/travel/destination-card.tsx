import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin } from "lucide-react"

interface DestinationCardProps {
  id: number
  name: string
  country: string
  city: string
  description: string
  image_url: string
}

export function DestinationCard({ id, name, country, city, description, image_url }: DestinationCardProps) {
  return (
    <Link href={`/destinations/${id}`}>
      <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
        <div className="relative h-48">
          <Image
            src={image_url || "/placeholder.svg?height=192&width=400&query=travel destination"}
            alt={name || "Destino de viagem"}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-4 left-4 text-white">
            <h3 className="font-semibold text-lg">{name || "Destino"}</h3>
            <div className="flex items-center text-sm">
              <MapPin className="h-4 w-4 mr-1" />
              {city || "Cidade"}, {country || "País"}
            </div>
          </div>
        </div>

        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground line-clamp-3">{description || "Descrição não disponível"}</p>
        </CardContent>
      </Card>
    </Link>
  )
}
