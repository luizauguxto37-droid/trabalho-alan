import Image from "next/image"
import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, Users, Star, Heart } from "lucide-react"

interface PackageCardProps {
  id: number
  name: string
  destination_name: string
  country: string
  city: string
  duration_days: number
  price: number
  image_url: string
  description: string
  max_people: number
  departure_date: string
}

export function PackageCard({
  id,
  name,
  destination_name,
  country,
  city,
  duration_days,
  price,
  image_url,
  description,
  max_people,
  departure_date,
}: PackageCardProps) {
  const formatPrice = (price: number) => {
    if (!price || isNaN(price)) return "Consulte preço"
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price)
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return "Data a definir"
    const date = new Date(dateString)
    if (isNaN(date.getTime())) return "Data a definir"
    return date.toLocaleDateString("pt-BR")
  }

  return (
    <Card className="overflow-hidden shadow-medium hover:shadow-large transition-all duration-300 border-0 group">
      <div className="relative h-56 overflow-hidden">
        <Image
          src={image_url || "/placeholder.svg?height=224&width=400&query=travel destination"}
          alt={name || "Pacote de viagem"}
          fill
          className="object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        <Badge className="absolute top-3 right-3 gradient-secondary border-0 text-white font-semibold">
          {duration_days || 0} dias ✈️
        </Badge>
        <Button
          variant="ghost"
          size="sm"
          className="absolute top-3 left-3 text-white hover:bg-white/20 hover:scale-110 transition-all"
        >
          <Heart className="h-4 w-4" />
        </Button>
      </div>

      <CardContent className="p-6">
        <div className="space-y-3">
          <div className="flex items-center text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 mr-1 text-primary" />📍 {city || "Cidade"}, {country || "País"}
          </div>

          <h3 className="font-bold text-xl line-clamp-2 group-hover:text-primary transition-colors">
            {name || "Pacote de viagem"}
          </h3>

          <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
            {description || "Descrição não disponível"}
          </p>

          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center text-muted-foreground">
              <Calendar className="h-4 w-4 mr-1 text-secondary" />
              {formatDate(departure_date)}
            </div>
            <div className="flex items-center text-muted-foreground">
              <Users className="h-4 w-4 mr-1 text-accent" />
              Até {max_people || 0} pessoas
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`h-4 w-4 ${i < 4 ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`} />
              ))}
              <span className="text-sm text-muted-foreground ml-2">(4.8) • 127 avaliações</span>
            </div>
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-6 pt-0 flex items-center justify-between">
        <div>
          <span className="text-3xl font-bold text-primary">{formatPrice(price)}</span>
          <span className="text-sm text-muted-foreground ml-1 block">por pessoa</span>
        </div>
        <Button asChild className="gradient-primary hover:opacity-90 transition-opacity font-semibold">
          <Link href={`/packages/${id}`}>Ver Detalhes 🔍</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
