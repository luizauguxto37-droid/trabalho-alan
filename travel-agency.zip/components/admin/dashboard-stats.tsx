"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Users, Package, DollarSign, TrendingUp, Clock } from "lucide-react"

interface DashboardStatsProps {
  stats: {
    total_bookings: number
    pending_bookings: number
    total_revenue: number
    total_users: number
    total_packages: number
    monthly_data: Array<{
      month: string
      count: number
      revenue: number
    }>
  }
}

export function DashboardStats({ stats }: DashboardStatsProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price)
  }

  const currentMonth = stats.monthly_data[stats.monthly_data.length - 1]
  const previousMonth = stats.monthly_data[stats.monthly_data.length - 2]

  const bookingGrowth = previousMonth ? ((currentMonth?.count - previousMonth.count) / previousMonth.count) * 100 : 0

  const revenueGrowth = previousMonth
    ? ((currentMonth?.revenue - previousMonth.revenue) / previousMonth.revenue) * 100
    : 0

  return (
    <div className="space-y-6">
      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Reservas</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total_bookings}</div>
            {bookingGrowth !== 0 && (
              <p className="text-xs text-muted-foreground">
                <span className={bookingGrowth > 0 ? "text-emerald-600" : "text-red-600"}>
                  {bookingGrowth > 0 ? "+" : ""}
                  {bookingGrowth.toFixed(1)}%
                </span>{" "}
                em relação ao mês anterior
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reservas Pendentes</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pending_bookings}</div>
            <p className="text-xs text-muted-foreground">Aguardando confirmação</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatPrice(stats.total_revenue)}</div>
            {revenueGrowth !== 0 && (
              <p className="text-xs text-muted-foreground">
                <span className={revenueGrowth > 0 ? "text-emerald-600" : "text-red-600"}>
                  {revenueGrowth > 0 ? "+" : ""}
                  {revenueGrowth.toFixed(1)}%
                </span>{" "}
                em relação ao mês anterior
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Usuários Ativos</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total_users}</div>
            <p className="text-xs text-muted-foreground">Clientes cadastrados</p>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Reservas por Mês</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.monthly_data.slice(-6).map((month, index) => (
                <div key={month.month} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    <span className="text-sm font-medium">
                      {new Date(month.month + "-01").toLocaleDateString("pt-BR", {
                        month: "long",
                        year: "numeric",
                      })}
                    </span>
                  </div>
                  <Badge variant="secondary">{month.count} reservas</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Receita por Mês</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.monthly_data.slice(-6).map((month, index) => (
                <div key={month.month} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                    <span className="text-sm font-medium">
                      {new Date(month.month + "-01").toLocaleDateString("pt-BR", {
                        month: "long",
                        year: "numeric",
                      })}
                    </span>
                  </div>
                  <Badge variant="outline">{formatPrice(month.revenue)}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Ações Rápidas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-3 p-4 border rounded-lg">
              <Package className="h-8 w-8 text-primary" />
              <div>
                <p className="font-medium">{stats.total_packages} Pacotes</p>
                <p className="text-sm text-muted-foreground">Ativos no sistema</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-4 border rounded-lg">
              <TrendingUp className="h-8 w-8 text-emerald-500" />
              <div>
                <p className="font-medium">Taxa de Conversão</p>
                <p className="text-sm text-muted-foreground">85% este mês</p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-4 border rounded-lg">
              <Users className="h-8 w-8 text-blue-500" />
              <div>
                <p className="font-medium">Satisfação</p>
                <p className="text-sm text-muted-foreground">4.8/5 estrelas</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
