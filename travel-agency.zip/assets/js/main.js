// Main JavaScript File
document.addEventListener("DOMContentLoaded", () => {
  // Mobile menu toggle
  const hamburger = document.querySelector(".hamburger")
  const navMenu = document.querySelector(".nav-menu")

  if (hamburger && navMenu) {
    hamburger.addEventListener("click", () => {
      navMenu.classList.toggle("active")
    })
  }

  // Load featured packages
  loadFeaturedPackages()

  // Load popular destinations
  loadPopularDestinations()

  // Initialize form validations
  initializeFormValidations()

  // Apply masks on page load
  const phoneInputs = document.querySelectorAll('input[name="telefone"]')
  phoneInputs.forEach(applyPhoneMask)

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Initialize search on page load
  initializeSearch()
})

// Load Featured Packages
async function loadFeaturedPackages() {
  const container = document.getElementById("featuredPackages")
  if (!container) return

  try {
    console.log("[v0] Iniciando carregamento de pacotes em destaque...")
    const response = await fetch("/api/packages?featured=true&limit=6")

    console.log("[v0] Response status:", response.status)
    console.log("[v0] Response headers:", response.headers.get("content-type"))

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const packages = await response.json()
    console.log("[v0] Parsed packages:", packages)

    if (packages.success && packages.data && packages.data.length > 0) {
      container.innerHTML = packages.data
        .map(
          (pkg) => `
                <div class="package-card">
                    <img src="${pkg.imagem || "/assets/images/default-package.jpg"}" alt="${pkg.nome}">
                    <div class="package-card-content">
                        <h3>${pkg.nome}</h3>
                        <p>${pkg.descricao}</p>
                        <div class="package-price">R$ ${formatPrice(pkg.preco)}</div>
                        <ul class="package-features">
                            <li><i class="fas fa-calendar"></i> ${pkg.duracao} dias</li>
                            <li><i class="fas fa-users"></i> Até ${pkg.max_pessoas} pessoas</li>
                            <li><i class="fas fa-plane"></i> Voo incluso</li>
                        </ul>
                        <a href="pacote.php?id=${pkg.id}" class="btn btn-primary">Ver Detalhes</a>
                    </div>
                </div>
            `,
        )
        .join("")
    } else {
      container.innerHTML = '<p class="text-center">Nenhum pacote em destaque encontrado.</p>'
    }
  } catch (error) {
    console.error("[v0] Erro ao carregar pacotes:", error)
    container.innerHTML = `
      <div class="error-message">
        <p>Erro ao carregar pacotes em destaque.</p>
        <p><small>Detalhes: ${error.message}</small></p>
        <button onclick="loadFeaturedPackages()" class="btn btn-secondary">Tentar Novamente</button>
      </div>
    `
  }
}

// Load Popular Destinations
async function loadPopularDestinations() {
  const container = document.getElementById("popularDestinations")
  if (!container) return

  try {
    console.log("[v0] Iniciando carregamento de destinos populares...")
    const response = await fetch("/api/destinations?popular=true&limit=6")

    console.log("[v0] Response status:", response.status)
    console.log("[v0] Response headers:", response.headers.get("content-type"))

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const destinations = await response.json()
    console.log("[v0] Parsed destinations:", destinations)

    if (destinations.success && destinations.data && destinations.data.length > 0) {
      container.innerHTML = destinations.data
        .map(
          (dest) => `
                <div class="destination-card">
                    <img src="${dest.imagem || "/assets/images/default-destination.jpg"}" alt="${dest.nome}">
                    <div class="destination-card-content">
                        <h3>${dest.nome}</h3>
                        <p>${dest.descricao}</p>
                        <a href="destino.php?id=${dest.id}" class="btn btn-secondary">Explorar</a>
                    </div>
                </div>
            `,
        )
        .join("")
    } else {
      container.innerHTML = '<p class="text-center">Nenhum destino popular encontrado.</p>'
    }
  } catch (error) {
    console.error("[v0] Erro ao carregar destinos:", error)
    container.innerHTML = `
      <div class="error-message">
        <p>Erro ao carregar destinos populares.</p>
        <p><small>Detalhes: ${error.message}</small></p>
        <button onclick="loadPopularDestinations()" class="btn btn-secondary">Tentar Novamente</button>
      </div>
    `
  }
}

// Format price
function formatPrice(price) {
  return Number.parseFloat(price).toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })
}

// Form Validations
function initializeFormValidations() {
  const forms = document.querySelectorAll("form[data-validate]")

  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      e.preventDefault()
      validateForm(this)
    })

    // Real-time validation
    const inputs = form.querySelectorAll("input, select, textarea")
    inputs.forEach((input) => {
      input.addEventListener("blur", function () {
        validateField(this)
      })
    })
  })
}

function validateForm(form) {
  const inputs = form.querySelectorAll("input[required], select[required], textarea[required]")
  let isValid = true

  inputs.forEach((input) => {
    if (!validateField(input)) {
      isValid = false
    }
  })

  if (isValid) {
    submitForm(form)
  }
}

function validateField(field) {
  const value = field.value.trim()
  const type = field.type
  let isValid = true
  let message = ""

  // Remove previous error
  clearFieldError(field)

  // Required validation
  if (field.hasAttribute("required") && !value) {
    isValid = false
    message = "Este campo é obrigatório"
  }

  // Email validation
  else if (type === "email" && value) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(value)) {
      isValid = false
      message = "Email inválido"
    }
  }

  // Phone validation
  else if (field.name === "telefone" && value) {
    const phoneRegex = /^$$\d{2}$$\s\d{4,5}-\d{4}$/
    if (!phoneRegex.test(value)) {
      isValid = false
      message = "Telefone inválido. Use o formato (11) 99999-9999"
    }
  }

  // Password validation
  else if (type === "password" && value) {
    if (value.length < 6) {
      isValid = false
      message = "A senha deve ter pelo menos 6 caracteres"
    }
  }

  // Confirm password validation
  else if (field.name === "confirm_password" && value) {
    const password = document.querySelector('input[name="senha"]')
    if (password && value !== password.value) {
      isValid = false
      message = "As senhas não coincidem"
    }
  }

  if (!isValid) {
    showFieldError(field, message)
  }

  return isValid
}

function showFieldError(field, message) {
  field.classList.add("error")

  let errorDiv = field.parentNode.querySelector(".error-message")
  if (!errorDiv) {
    errorDiv = document.createElement("div")
    errorDiv.className = "error-message"
    field.parentNode.appendChild(errorDiv)
  }

  errorDiv.textContent = message
}

function clearFieldError(field) {
  field.classList.remove("error")
  const errorDiv = field.parentNode.querySelector(".error-message")
  if (errorDiv) {
    errorDiv.remove()
  }
}

async function submitForm(form) {
  const submitBtn = form.querySelector('button[type="submit"]')
  const originalText = submitBtn.innerHTML

  // Show loading
  submitBtn.innerHTML = '<span class="loading"></span> Enviando...'
  submitBtn.disabled = true

  try {
    const formData = new FormData(form)
    const response = await fetch(form.action, {
      method: "POST",
      body: formData,
    })

    const result = await response.json()

    if (result.success) {
      showAlert("success", result.message)
      if (result.redirect) {
        setTimeout(() => {
          window.location.href = result.redirect
        }, 1500)
      } else {
        form.reset()
      }
    } else {
      showAlert("error", result.message)
    }
  } catch (error) {
    console.error("Erro ao enviar formulário:", error)
    showAlert("error", "Erro ao processar solicitação. Tente novamente.")
  } finally {
    // Restore button
    submitBtn.innerHTML = originalText
    submitBtn.disabled = false
  }
}

function showAlert(type, message) {
  // Remove existing alerts
  const existingAlerts = document.querySelectorAll(".alert")
  existingAlerts.forEach((alert) => alert.remove())

  // Create new alert
  const alert = document.createElement("div")
  alert.className = `alert alert-${type}`
  alert.textContent = message

  // Insert at top of main content
  const main = document.querySelector("main") || document.body
  main.insertBefore(alert, main.firstChild)

  // Auto remove after 5 seconds
  setTimeout(() => {
    alert.remove()
  }, 5000)
}

// Phone mask
function applyPhoneMask(input) {
  input.addEventListener("input", (e) => {
    let value = e.target.value.replace(/\D/g, "")

    if (value.length <= 11) {
      value = value.replace(/(\d{2})(\d)/, "($1) $2")
      value = value.replace(/(\d{4})(\d)/, "$1-$2")
      value = value.replace(/(\d{4})-(\d)(\d{4})/, "$1$2-$3")
    }

    e.target.value = value
  })
}

// Search functionality
function initializeSearch() {
  const searchForm = document.getElementById("searchForm")
  if (!searchForm) return

  searchForm.addEventListener("submit", function (e) {
    e.preventDefault()

    const formData = new FormData(this)
    const params = new URLSearchParams(formData)

    window.location.href = `pacotes.php?${params.toString()}`
  })
}
