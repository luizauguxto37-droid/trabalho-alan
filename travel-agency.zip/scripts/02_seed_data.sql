-- Inserindo dados iniciais para demonstração

USE travel_agency;

-- Inserir usuário administrador padrão
INSERT INTO users (name, email, password, user_type) VALUES 
('Administrador', 'admin@travelagency.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Inserir destinos populares
INSERT INTO destinations (name, country, state, city, description, image_url, featured) VALUES 
('Paris - Cidade Luz', 'França', '', 'Paris', 'A romântica capital francesa com sua Torre Eiffel, Louvre e charme único.', '/placeholder.svg?height=400&width=600', TRUE),
('Rio de Janeiro', 'Brasil', 'RJ', 'Rio de Janeiro', 'Cidade maravilhosa com Cristo Redentor, Copacabana e Pão de Açúcar.', '/placeholder.svg?height=400&width=600', TRUE),
('Tóquio', 'Japão', '', 'Tóquio', 'Metrópole moderna que mescla tradição e tecnologia de forma única.', '/placeholder.svg?height=400&width=600', TRUE),
('Machu Picchu', 'Peru', '', 'Cusco', 'Antiga cidade inca nas montanhas dos Andes peruanos.', '/placeholder.svg?height=400&width=600', TRUE),
('Santorini', 'Grécia', '', 'Santorini', 'Ilha grega com casas brancas, mar azul e pôr do sol inesquecível.', '/placeholder.svg?height=400&width=600', TRUE);

-- Inserir pacotes de viagem
INSERT INTO travel_packages (destination_id, name, description, duration_days, price, max_people, includes, excludes, image_url, departure_date, return_date) VALUES 
(1, 'Paris Romântico - 7 dias', 'Pacote completo para conhecer o melhor de Paris em uma semana inesquecível.', 7, 4500.00, 20, 'Passagem aérea, hospedagem 4 estrelas, café da manhã, city tour, ingresso Torre Eiffel e Louvre', 'Almoço, jantar, seguro viagem', '/placeholder.svg?height=300&width=500', '2024-06-15', '2024-06-22'),
(2, 'Rio Maravilhoso - 5 dias', 'Descubra as belezas naturais e culturais do Rio de Janeiro.', 5, 2800.00, 25, 'Hospedagem em Copacabana, café da manhã, city tour, Cristo Redentor, Pão de Açúcar', 'Passagem aérea, refeições, seguro viagem', '/placeholder.svg?height=300&width=500', '2024-07-10', '2024-07-15'),
(3, 'Tóquio Cultural - 10 dias', 'Imersão completa na cultura japonesa com guia especializado.', 10, 8500.00, 15, 'Passagem aérea, hospedagem, café da manhã, JR Pass, guia em português, templos principais', 'Almoço, jantar, compras pessoais', '/placeholder.svg?height=300&width=500', '2024-08-20', '2024-08-30'),
(4, 'Trilha Inca - 8 dias', 'Aventura única pela trilha inca até Machu Picchu.', 8, 3200.00, 12, 'Hospedagem, todas as refeições, guia especializado, equipamentos, ingressos', 'Passagem aérea, seguro viagem, equipamentos pessoais', '/placeholder.svg?height=300&width=500', '2024-09-05', '2024-09-13'),
(5, 'Santorini Lua de Mel - 6 dias', 'Pacote romântico para casais na paradisíaca ilha grega.', 6, 5200.00, 10, 'Passagem aérea, hospedagem com vista para o mar, café da manhã, jantar romântico, passeio de barco', 'Almoço, seguro viagem, atividades extras', '/placeholder.svg?height=300&width=500', '2024-10-12', '2024-10-18');

-- Inserir algumas avaliações de exemplo
INSERT INTO reviews (user_id, package_id, rating, comment) VALUES 
(1, 1, 5, 'Viagem incrível! Paris superou todas as expectativas. Organização perfeita!'),
(1, 2, 4, 'Rio de Janeiro é maravilhoso mesmo. Só faltou mais tempo para aproveitar tudo.'),
(1, 3, 5, 'Experiência única no Japão. Guia excelente e roteiro bem planejado.');
