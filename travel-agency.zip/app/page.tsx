"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PackageCard } from "@/components/travel/package-card"
import { DestinationCard } from "@/components/travel/destination-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Shield, Clock, Star, Quote, Sparkles, Globe, Heart } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const [featuredPackages, setFeaturedPackages] = useState([])
  const [featuredDestinations, setFeaturedDestinations] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const [packagesRes, destinationsRes] = await Promise.all([
          fetch("/api/packages?featured=true&limit=6"),
          fetch("/api/destinations?popular=true&limit=6"),
        ])

        const packagesData = await packagesRes.json()
        const destinationsData = await destinationsRes.json()

        if (packagesData.success) {
          setFeaturedPackages(packagesData.data)
        }

        if (destinationsData.success) {
          setFeaturedDestinations(destinationsData.data)
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchTerm.trim()) {
      window.location.href = `/packages?search=${encodeURIComponent(searchTerm)}`
    }
  }

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="relative h-[700px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 gradient-hero" />
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-30"
          style={{
            backgroundImage: "url('/beautiful-tropical-beach-with-palm-trees-and-cryst.png')",
          }}
        />

        <div className="absolute top-20 left-10 animate-float">
          <div className="w-20 h-20 bg-white/10 rounded-full glass-effect" />
        </div>
        <div className="absolute top-40 right-20 animate-float" style={{ animationDelay: "2s" }}>
          <div className="w-16 h-16 bg-white/10 rounded-full glass-effect" />
        </div>
        <div className="absolute bottom-32 left-20 animate-float" style={{ animationDelay: "4s" }}>
          <div className="w-12 h-12 bg-white/10 rounded-full glass-effect" />
        </div>

        <div className="relative z-10 text-center text-white max-w-5xl mx-auto px-4">
          <div className="animate-fade-in">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 text-balance text-shadow">
              Descubra o Mundo com a
              <span className="block bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                ViagemPlus
              </span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-balance text-shadow opacity-90">
              ✈️ Experiências únicas, destinos incríveis e memórias para toda vida 🌍
            </p>
          </div>

          {/* Search Bar */}
          <form
            onSubmit={handleSearch}
            className="flex max-w-lg mx-auto glass-effect rounded-2xl overflow-hidden shadow-large animate-bounce-slow"
          >
            <Input
              type="text"
              placeholder="🔍 Para onde você quer ir?"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border-0 focus-visible:ring-0 text-gray-900 bg-white/90 placeholder:text-gray-600"
            />
            <Button type="submit" className="rounded-none gradient-secondary hover:opacity-90 transition-opacity">
              <Search className="h-4 w-4" />
            </Button>
          </form>

          <div className="flex flex-wrap justify-center gap-4 mt-8">
            <div className="glass-effect px-4 py-2 rounded-full text-sm">
              <Sparkles className="inline h-4 w-4 mr-2" />
              +1000 Destinos
            </div>
            <div className="glass-effect px-4 py-2 rounded-full text-sm">
              <Heart className="inline h-4 w-4 mr-2" />
              98% Satisfação
            </div>
            <div className="glass-effect px-4 py-2 rounded-full text-sm">
              <Globe className="inline h-4 w-4 mr-2" />
              50+ Países
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-gradient">Por que escolher a ViagemPlus?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Mais de 10 anos criando experiências inesquecíveis
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center group hover-lift">
              <Card className="border-0 shadow-medium hover:shadow-large transition-all duration-300">
                <CardContent className="p-8">
                  <div className="w-20 h-20 gradient-primary rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                    <Shield className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Segurança Garantida</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Viaje com tranquilidade. Todos os nossos pacotes incluem seguro viagem completo e suporte 24h.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="text-center group hover-lift">
              <Card className="border-0 shadow-medium hover:shadow-large transition-all duration-300">
                <CardContent className="p-8">
                  <div className="w-20 h-20 gradient-secondary rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                    <Clock className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Suporte 24/7</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Nossa equipe especializada está sempre disponível para ajudar você durante toda a viagem.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="text-center group hover-lift">
              <Card className="border-0 shadow-medium hover:shadow-large transition-all duration-300">
                <CardContent className="p-8">
                  <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                    <Star className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Experiências Únicas</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Roteiros exclusivos e experiências autênticas que você não encontra em outro lugar.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Packages */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="text-gradient">Pacotes em Destaque</span> ✨
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Descubra nossos pacotes mais populares e embarque na aventura dos seus sonhos
            </p>
          </div>

          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
              <p className="mt-4 text-muted-foreground text-lg">Carregando pacotes incríveis...</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                {featuredPackages.map((pkg: any) => (
                  <div key={pkg.id} className="hover-lift">
                    <PackageCard {...pkg} />
                  </div>
                ))}
              </div>

              <div className="text-center">
                <Button
                  asChild
                  size="lg"
                  className="gradient-primary hover:opacity-90 transition-opacity text-lg px-8 py-3"
                >
                  <Link href="/packages">🌟 Ver Todos os Pacotes</Link>
                </Button>
              </div>
            </>
          )}
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-16 bg-muted/50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Destinos Populares</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Explore os destinos mais procurados pelos nossos viajantes
            </p>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              <p className="mt-2 text-muted-foreground">Carregando destinos...</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {featuredDestinations.map((destination: any) => (
                  <DestinationCard key={destination.id} {...destination} />
                ))}
              </div>

              <div className="text-center">
                <Button asChild size="lg" variant="outline">
                  <Link href="/destinations">Explorar Destinos</Link>
                </Button>
              </div>
            </>
          )}
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">O Que Nossos Clientes Dizem</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: "Maria Silva",
                location: "São Paulo, SP",
                comment:
                  "Viagem incrível para Paris! Tudo muito bem organizado, desde o hotel até os passeios. Recomendo muito!",
                rating: 5,
              },
              {
                name: "João Santos",
                location: "Rio de Janeiro, RJ",
                comment: "A trilha inca foi uma experiência única na vida. Guias excelentes e toda logística perfeita.",
                rating: 5,
              },
              {
                name: "Ana Costa",
                location: "Belo Horizonte, MG",
                comment: "Lua de mel em Santorini foi um sonho realizado. Atendimento excepcional do início ao fim.",
                rating: 5,
              },
            ].map((testimonial, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <Quote className="h-8 w-8 text-primary mb-4" />
                  <p className="text-muted-foreground mb-4">"{testimonial.comment}"</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                    </div>
                    <div className="flex">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-hero text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="container text-center relative z-10">
          <div className="animate-pulse-slow">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-shadow">🚀 Pronto para Sua Próxima Aventura?</h2>
            <p className="text-xl mb-10 max-w-2xl mx-auto leading-relaxed text-shadow">
              Entre em contato conosco e deixe que nossos especialistas criem a viagem perfeita para você
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button size="lg" variant="secondary" asChild className="text-lg px-8 py-3 hover-scale">
              <Link href="/contact">💬 Fale Conosco</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="text-lg px-8 py-3 hover-scale border-white text-white hover:bg-white hover:text-primary bg-transparent"
            >
              <Link href="/packages">🎯 Ver Pacotes</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
