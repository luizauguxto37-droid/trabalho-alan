import { type NextRequest, NextResponse } from "next/server"

const mockDestinations = [
  {
    id: 1,
    name: "Paris",
    country: "França",
    city: "Paris",
    description: "A cidade luz, capital mundial do romance e da cultura",
    image_url: "/paris-eiffel-tower-and-seine-river-at-sunset.jpg",
    popular: true,
    active: true,
    created_at: "2024-01-15",
  },
  {
    id: 2,
    name: "Rio de Janeiro",
    country: "Brasil",
    city: "Rio de Janeiro",
    description: "Cidade maravilhosa com praias deslumbrantes e cultura vibrante",
    image_url: "/rio-de-janeiro-christ-the-redeemer-statue-and-suga.jpg",
    popular: true,
    active: true,
    created_at: "2024-01-10",
  },
  {
    id: 3,
    name: "Machu Picchu",
    country: "Peru",
    city: "Cusco",
    description: "Antiga cidade inca perdida nas montanhas do Peru",
    image_url: "/machu-picchu-ancient-inca-ruins-in-the-mountains.jpg",
    popular: true,
    active: true,
    created_at: "2024-01-08",
  },
  {
    id: 4,
    name: "Cancún",
    country: "México",
    city: "Cancún",
    description: "Paraíso tropical com praias de areia branca e mar turquesa",
    image_url: "/cancun-tropical-beach-with-white-sand-and-turquois.jpg",
    popular: false,
    active: true,
    created_at: "2024-01-05",
  },
  {
    id: 5,
    name: "Gramado",
    country: "Brasil",
    city: "Gramado",
    description: "Charme europeu no sul do Brasil com arquitetura única",
    image_url: "/gramado-european-style-architecture-in-brazil.jpg",
    popular: true,
    active: true,
    created_at: "2024-01-03",
  },
  {
    id: 6,
    name: "Bariloche",
    country: "Argentina",
    city: "Bariloche",
    description: "Paisagens alpinas deslumbrantes na Patagônia argentina",
    image_url: "/bariloche-alpine-landscapes-in-patagonia.jpg",
    popular: true,
    active: true,
    created_at: "2024-01-01",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const popular = searchParams.get("popular") === "true"
    const limit = Number.parseInt(searchParams.get("limit") || "6")

    let filteredDestinations = mockDestinations.filter((dest) => dest.active === true)

    if (popular) {
      filteredDestinations = filteredDestinations.filter((dest) => dest.popular === true)
    }

    // Simular ordenação por nome
    filteredDestinations.sort((a, b) => a.name.localeCompare(b.name))

    // Aplicar limite
    filteredDestinations = filteredDestinations.slice(0, limit)

    return NextResponse.json({
      success: true,
      data: filteredDestinations,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Erro ao buscar destinos: " + (error as Error).message,
      },
      { status: 500 },
    )
  }
}
