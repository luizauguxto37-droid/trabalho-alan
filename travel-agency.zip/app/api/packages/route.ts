import { type NextRequest, NextResponse } from "next/server"

const mockPackages = [
  {
    id: 1,
    name: "Paris Romântico",
    description: "Descubra a cidade luz com este pacote romântico de 7 dias",
    price: 4500.0,
    duration_days: 7,
    max_people: 2,
    destination_id: 1,
    destination_name: "Paris",
    country: "França",
    city: "Paris",
    image_url: "/paris-eiffel-tower-and-seine-river-at-sunset.jpg",
    departure_date: "2024-03-15",
    featured: true,
    active: true,
    created_at: "2024-01-15",
  },
  {
    id: 2,
    name: "Rio de Janeiro Completo",
    description: "Conheça as maravilhas do Rio em 5 dias inesquecíveis",
    price: 2800.0,
    duration_days: 5,
    max_people: 4,
    destination_id: 2,
    destination_name: "Rio de Janeiro",
    country: "Brasil",
    city: "Rio de Janeiro",
    image_url: "/rio-de-janeiro-christ-the-redeemer-statue-and-suga.jpg",
    departure_date: "2024-03-20",
    featured: true,
    active: true,
    created_at: "2024-01-10",
  },
  {
    id: 3,
    name: "Machu Picchu Aventura",
    description: "Trilha épica até a cidade perdida dos Incas",
    price: 3200.0,
    duration_days: 6,
    max_people: 8,
    destination_id: 3,
    destination_name: "Machu Picchu",
    country: "Peru",
    city: "Cusco",
    image_url: "/machu-picchu-ancient-inca-ruins-in-the-mountains.jpg",
    departure_date: "2024-04-10",
    featured: true,
    active: true,
    created_at: "2024-01-08",
  },
  {
    id: 4,
    name: "Cancún Tropical",
    description: "Relaxe nas praias paradisíacas do Caribe mexicano",
    price: 3800.0,
    duration_days: 7,
    max_people: 6,
    destination_id: 4,
    destination_name: "Cancún",
    country: "México",
    city: "Cancún",
    image_url: "/cancun-tropical-beach-with-white-sand-and-turquois.jpg",
    departure_date: "2024-04-05",
    featured: false,
    active: true,
    created_at: "2024-01-05",
  },
  {
    id: 5,
    name: "Gramado Encantado",
    description: "Charme europeu no coração do Rio Grande do Sul",
    price: 1800.0,
    duration_days: 4,
    max_people: 4,
    destination_id: 5,
    destination_name: "Gramado",
    country: "Brasil",
    city: "Gramado",
    image_url: "/gramado-european-style-architecture-in-brazil.jpg",
    departure_date: "2024-03-25",
    featured: true,
    active: true,
    created_at: "2024-01-03",
  },
  {
    id: 6,
    name: "Bariloche Aventura",
    description: "Paisagens alpinas e aventuras na Patagônia",
    price: 2900.0,
    duration_days: 6,
    max_people: 6,
    destination_id: 6,
    destination_name: "Bariloche",
    country: "Argentina",
    city: "Bariloche",
    image_url: "/bariloche-alpine-landscapes-in-patagonia.jpg",
    departure_date: "2024-04-15",
    featured: false,
    active: true,
    created_at: "2024-01-01",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const featured = searchParams.get("featured") === "true"
    const limit = Number.parseInt(searchParams.get("limit") || "6")

    let filteredPackages = mockPackages.filter((pkg) => pkg.active === true)

    if (featured) {
      filteredPackages = filteredPackages.filter((pkg) => pkg.featured === true)
    }

    // Simular ordenação por data de criação (mais recentes primeiro)
    filteredPackages.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())

    // Aplicar limite
    filteredPackages = filteredPackages.slice(0, limit)

    return NextResponse.json({
      success: true,
      data: filteredPackages,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Erro ao buscar pacotes: " + (error as Error).message,
      },
      { status: 500 },
    )
  }
}
