"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PackageCard } from "@/components/travel/package-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Filter } from "lucide-react"

export default function PackagesPage() {
  const [packages, setPackages] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    destination: "",
    min_price: "",
    max_price: "",
    duration: "0", // Updated default value to be a non-empty string
  })

  useEffect(() => {
    fetchPackages()
  }, [])

  const fetchPackages = async (searchFilters = filters) => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.append("action", "search")

      Object.entries(searchFilters).forEach(([key, value]) => {
        if (value) params.append(key, value)
      })

      const response = await fetch(`/api/packages.php?${params}`)
      const data = await response.json()

      if (data.success) {
        setPackages(data.data)
      }
    } catch (error) {
      console.error("Erro ao buscar pacotes:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleFilterChange = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value }
    setFilters(newFilters)
  }

  const handleSearch = () => {
    fetchPackages(filters)
  }

  const clearFilters = () => {
    const emptyFilters = {
      destination: "",
      min_price: "",
      max_price: "",
      duration: "0", // Updated default value to be a non-empty string
    }
    setFilters(emptyFilters)
    fetchPackages(emptyFilters)
  }

  return (
    <div className="min-h-screen">
      <Header />

      {/* Page Header */}
      <section className="py-16 bg-gradient-to-r from-primary to-secondary text-primary-foreground">
        <div className="container text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Nossos Pacotes de Viagem</h1>
          <p className="text-xl max-w-2xl mx-auto">Encontre o pacote perfeito para sua próxima aventura</p>
        </div>
      </section>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Filtros
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="destination">Destino</Label>
                  <Input
                    id="destination"
                    placeholder="Digite o destino..."
                    value={filters.destination}
                    onChange={(e) => handleFilterChange("destination", e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="duration">Duração</Label>
                  <Select value={filters.duration} onValueChange={(value) => handleFilterChange("duration", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a duração" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">Todas</SelectItem>
                      <SelectItem value="3">3 dias</SelectItem>
                      <SelectItem value="5">5 dias</SelectItem>
                      <SelectItem value="7">7 dias</SelectItem>
                      <SelectItem value="10">10 dias</SelectItem>
                      <SelectItem value="14">14 dias</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="min_price">Preço Mín.</Label>
                    <Input
                      id="min_price"
                      type="number"
                      placeholder="R$ 0"
                      value={filters.min_price}
                      onChange={(e) => handleFilterChange("min_price", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="max_price">Preço Máx.</Label>
                    <Input
                      id="max_price"
                      type="number"
                      placeholder="R$ 10000"
                      value={filters.max_price}
                      onChange={(e) => handleFilterChange("max_price", e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Button onClick={handleSearch} className="w-full">
                    <Search className="h-4 w-4 mr-2" />
                    Buscar
                  </Button>
                  <Button onClick={clearFilters} variant="outline" className="w-full bg-transparent">
                    Limpar Filtros
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Packages Grid */}
          <div className="lg:col-span-3">
            {loading ? (
              <div className="text-center py-12">
                <p>Carregando pacotes...</p>
              </div>
            ) : packages.length > 0 ? (
              <>
                <div className="flex justify-between items-center mb-6">
                  <p className="text-muted-foreground">{packages.length} pacote(s) encontrado(s)</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {packages.map((pkg: any) => (
                    <PackageCard key={pkg.id} {...pkg} />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Nenhum pacote encontrado com os filtros selecionados.</p>
                <Button onClick={clearFilters} className="mt-4">
                  Ver Todos os Pacotes
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
