"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Image from "next/image"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { BookingForm } from "@/components/booking/booking-form"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Calendar, Users, Clock, Check, X, Star, Plane } from "lucide-react"

export default function PackageDetailPage() {
  const params = useParams()
  const [packageData, setPackageData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [showBookingForm, setShowBookingForm] = useState(false)

  useEffect(() => {
    if (params.id) {
      fetchPackageDetails(params.id as string)
    }
  }, [params.id])

  const fetchPackageDetails = async (id: string) => {
    try {
      const response = await fetch(`/api/packages.php?action=single&id=${id}`)
      const data = await response.json()

      if (data.success) {
        setPackageData(data.data)
      }
    } catch (error) {
      console.error("Erro ao buscar detalhes do pacote:", error)
    } finally {
      setLoading(false)
    }
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  if (loading) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container py-16 text-center">
          <p>Carregando detalhes do pacote...</p>
        </div>
        <Footer />
      </div>
    )
  }

  if (!packageData) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Pacote não encontrado</h1>
          <Button onClick={() => window.history.back()}>Voltar</Button>
        </div>
        <Footer />
      </div>
    )
  }

  if (showBookingForm) {
    return (
      <div className="min-h-screen">
        <Header />
        <div className="container py-8">
          <div className="mb-6">
            <Button variant="outline" onClick={() => setShowBookingForm(false)}>
              ← Voltar aos Detalhes
            </Button>
          </div>
          <h1 className="text-3xl font-bold mb-8 text-center">Finalizar Reserva</h1>
          <BookingForm packageData={packageData} />
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Image */}
      <div className="relative h-96">
        <Image src={packageData.image_url || "/placeholder.svg"} alt={packageData.name} fill className="object-cover" />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute bottom-6 left-6 text-white">
          <Badge className="mb-2">{packageData.duration_days} dias</Badge>
          <h1 className="text-4xl font-bold mb-2">{packageData.name}</h1>
          <div className="flex items-center text-lg">
            <MapPin className="h-5 w-5 mr-2" />
            {packageData.city}, {packageData.country}
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                <TabsTrigger value="includes">Inclui/Não Inclui</TabsTrigger>
                <TabsTrigger value="reviews">Avaliações</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Sobre este Pacote</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed">{packageData.description}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Informações da Viagem</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <Clock className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="font-semibold">{packageData.duration_days} dias</p>
                        <p className="text-sm text-muted-foreground">Duração</p>
                      </div>

                      <div className="text-center">
                        <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="font-semibold">Até {packageData.max_people}</p>
                        <p className="text-sm text-muted-foreground">Pessoas</p>
                      </div>

                      <div className="text-center">
                        <Calendar className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="font-semibold">{formatDate(packageData.departure_date)}</p>
                        <p className="text-sm text-muted-foreground">Partida</p>
                      </div>

                      <div className="text-center">
                        <Plane className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="font-semibold">{formatDate(packageData.return_date)}</p>
                        <p className="text-sm text-muted-foreground">Retorno</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="includes" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-emerald-600 flex items-center">
                        <Check className="h-5 w-5 mr-2" />O que está incluído
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {packageData.includes?.split(",").map((item: string, index: number) => (
                          <li key={index} className="flex items-start">
                            <Check className="h-4 w-4 text-emerald-600 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{item.trim()}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-red-600 flex items-center">
                        <X className="h-5 w-5 mr-2" />O que não está incluído
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {packageData.excludes?.split(",").map((item: string, index: number) => (
                          <li key={index} className="flex items-start">
                            <X className="h-4 w-4 text-red-600 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{item.trim()}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="reviews">
                <Card>
                  <CardHeader>
                    <CardTitle>Avaliações dos Clientes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          name: "Maria Silva",
                          rating: 5,
                          comment: "Experiência incrível! Tudo muito bem organizado e os guias foram excelentes.",
                          date: "2024-01-15",
                        },
                        {
                          name: "João Santos",
                          rating: 4,
                          comment: "Viagem maravilhosa, só faltou um pouco mais de tempo livre para explorar.",
                          date: "2024-01-10",
                        },
                      ].map((review, index) => (
                        <div key={index} className="border-b pb-4 last:border-b-0">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center">
                              <span className="font-semibold mr-2">{review.name}</span>
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-4 w-4 ${
                                      i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                            <span className="text-sm text-muted-foreground">{formatDate(review.date)}</span>
                          </div>
                          <p className="text-muted-foreground">{review.comment}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Booking Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="text-center">
                  <span className="text-3xl font-bold text-primary">{formatPrice(packageData.price)}</span>
                  <span className="text-sm text-muted-foreground ml-2">por pessoa</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Duração:</span>
                    <span>{packageData.duration_days} dias</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Máximo de pessoas:</span>
                    <span>{packageData.max_people}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Partida:</span>
                    <span>{formatDate(packageData.departure_date)}</span>
                  </div>
                </div>

                <Separator />

                <Button size="lg" className="w-full" onClick={() => setShowBookingForm(true)}>
                  Reservar Agora
                </Button>

                <p className="text-xs text-center text-muted-foreground">
                  Pagamento seguro • Cancelamento gratuito até 48h antes
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
