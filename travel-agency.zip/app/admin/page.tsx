"use client"

import { useState, useEffect } from "react"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { DashboardStats } from "@/components/admin/dashboard-stats"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Calendar, Users, Package, MessageSquare, Plus } from "lucide-react"
import Link from "next/link"

export default function AdminDashboard() {
  const [stats, setStats] = useState<any>(null)
  const [recentBookings, setRecentBookings] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      // Buscar estatísticas do dashboard
      const statsResponse = await fetch("/api/admin.php?action=dashboard")
      const statsData = await statsResponse.json()

      if (statsData.success) {
        setStats(statsData.data)
      }

      // Buscar reservas recentes
      const bookingsResponse = await fetch("/api/bookings.php?action=all")
      const bookingsData = await bookingsResponse.json()

      if (bookingsData.success) {
        setRecentBookings(bookingsData.data.slice(0, 5)) // Últimas 5 reservas
      }
    } catch (err) {
      setError("Erro ao carregar dados do dashboard")
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      pending: { label: "Pendente", variant: "secondary" as const },
      confirmed: { label: "Confirmada", variant: "default" as const },
      cancelled: { label: "Cancelada", variant: "destructive" as const },
      completed: { label: "Concluída", variant: "outline" as const },
    }

    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.pending
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("pt-BR")
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price)
  }

  if (loading) {
    return (
      <div className="flex h-screen">
        <AdminSidebar />
        <div className="flex-1 lg:ml-64 p-8">
          <div className="text-center">
            <p>Carregando dashboard...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-muted/50">
      <AdminSidebar />

      <div className="flex-1 lg:ml-64 overflow-auto">
        <div className="p-6 lg:p-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold">Dashboard</h1>
              <p className="text-muted-foreground">Visão geral da sua agência de viagens</p>
            </div>
            <div className="flex space-x-2 mt-4 sm:mt-0">
              <Button asChild>
                <Link href="/admin/packages/new">
                  <Plus className="h-4 w-4 mr-2" />
                  Novo Pacote
                </Link>
              </Button>
            </div>
          </div>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Dashboard Stats */}
          {stats && <DashboardStats stats={stats} />}

          {/* Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            {/* Recent Bookings */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Reservas Recentes
                </CardTitle>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/admin/bookings">Ver Todas</Link>
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentBookings.length > 0 ? (
                    recentBookings.map((booking: any) => (
                      <div key={booking.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium">{booking.user_name}</p>
                          <p className="text-sm text-muted-foreground">{booking.package_name}</p>
                          <p className="text-xs text-muted-foreground">{formatDate(booking.created_at)}</p>
                        </div>
                        <div className="text-right">
                          {getStatusBadge(booking.status)}
                          <p className="text-sm font-medium mt-1">{formatPrice(booking.total_price)}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-muted-foreground py-4">Nenhuma reserva recente</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="h-5 w-5 mr-2" />
                  Ações Rápidas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/admin/packages/new">
                      <Plus className="h-4 w-4 mr-2" />
                      Criar Novo Pacote
                    </Link>
                  </Button>

                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/admin/destinations/new">
                      <Plus className="h-4 w-4 mr-2" />
                      Adicionar Destino
                    </Link>
                  </Button>

                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/admin/bookings?status=pending">
                      <Calendar className="h-4 w-4 mr-2" />
                      Reservas Pendentes
                    </Link>
                  </Button>

                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/admin/users">
                      <Users className="h-4 w-4 mr-2" />
                      Gerenciar Usuários
                    </Link>
                  </Button>

                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/admin/messages">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Ver Mensagens
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
