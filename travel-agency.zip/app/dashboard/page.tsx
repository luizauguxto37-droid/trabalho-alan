"use client"

import { useState, useEffect } from "react"
import { ClientSidebar } from "@/components/client/client-sidebar"
import { BookingCard } from "@/components/client/booking-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Calendar, Package, Star, Heart, Plus, Plane } from "lucide-react"
import Link from "next/link"

export default function ClientDashboard() {
  const [userBookings, setUserBookings] = useState([])
  const [stats, setStats] = useState({
    total_bookings: 0,
    upcoming_trips: 0,
    completed_trips: 0,
    total_spent: 0,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      // Buscar reservas do usuário
      const bookingsResponse = await fetch("/api/bookings.php?action=user_bookings")
      const bookingsData = await bookingsResponse.json()

      if (bookingsData.success) {
        const bookings = bookingsData.data
        setUserBookings(bookings.slice(0, 3)) // Últimas 3 reservas

        // Calcular estatísticas
        const now = new Date()
        const upcoming = bookings.filter(
          (b: any) => new Date(b.travel_date) > now && (b.status === "confirmed" || b.status === "pending"),
        )
        const completed = bookings.filter((b: any) => b.status === "completed")
        const totalSpent = bookings
          .filter((b: any) => b.payment_status === "paid")
          .reduce((sum: number, b: any) => sum + Number.parseFloat(b.total_price), 0)

        setStats({
          total_bookings: bookings.length,
          upcoming_trips: upcoming.length,
          completed_trips: completed.length,
          total_spent: totalSpent,
        })
      }
    } catch (err) {
      setError("Erro ao carregar dados do dashboard")
    } finally {
      setLoading(false)
    }
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price)
  }

  if (loading) {
    return (
      <div className="flex h-screen">
        <ClientSidebar />
        <div className="flex-1 lg:ml-64 p-8">
          <div className="text-center">
            <p>Carregando dashboard...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-muted/50">
      <ClientSidebar />

      <div className="flex-1 lg:ml-64 overflow-auto">
        <div className="p-6 lg:p-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold">Bem-vindo de volta!</h1>
              <p className="text-muted-foreground">Gerencie suas viagens e explore novos destinos</p>
            </div>
            <Button asChild>
              <Link href="/packages">
                <Plus className="h-4 w-4 mr-2" />
                Nova Viagem
              </Link>
            </Button>
          </div>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Viagens</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total_bookings}</div>
                <p className="text-xs text-muted-foreground">Reservas realizadas</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Próximas Viagens</CardTitle>
                <Plane className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.upcoming_trips}</div>
                <p className="text-xs text-muted-foreground">Confirmadas ou pendentes</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Viagens Concluídas</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.completed_trips}</div>
                <p className="text-xs text-muted-foreground">Experiências vividas</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Investido</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatPrice(stats.total_spent)}</div>
                <p className="text-xs text-muted-foreground">Em experiências</p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Bookings */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    Minhas Reservas Recentes
                  </CardTitle>
                  <Button variant="outline" size="sm" asChild>
                    <Link href="/dashboard/bookings">Ver Todas</Link>
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {userBookings.length > 0 ? (
                      userBookings.map((booking: any) => <BookingCard key={booking.id} booking={booking} />)
                    ) : (
                      <div className="text-center py-8">
                        <Plane className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-semibold mb-2">Nenhuma reserva ainda</h3>
                        <p className="text-muted-foreground mb-4">Que tal planejar sua próxima aventura?</p>
                        <Button asChild>
                          <Link href="/packages">Explorar Pacotes</Link>
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Heart className="h-5 w-5 mr-2" />
                    Ações Rápidas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/packages">
                      <Package className="h-4 w-4 mr-2" />
                      Explorar Pacotes
                    </Link>
                  </Button>

                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/dashboard/favorites">
                      <Heart className="h-4 w-4 mr-2" />
                      Meus Favoritos
                    </Link>
                  </Button>

                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/dashboard/profile">
                      <Calendar className="h-4 w-4 mr-2" />
                      Editar Perfil
                    </Link>
                  </Button>

                  <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                    <Link href="/dashboard/reviews">
                      <Star className="h-4 w-4 mr-2" />
                      Minhas Avaliações
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Travel Tips */}
              <Card>
                <CardHeader>
                  <CardTitle>Dica de Viagem</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <h4 className="font-semibold text-sm mb-1">Documentação</h4>
                      <p className="text-xs text-muted-foreground">
                        Sempre verifique a validade do seu passaporte antes de viajar para o exterior.
                      </p>
                    </div>

                    <div className="p-3 bg-secondary/10 rounded-lg">
                      <h4 className="font-semibold text-sm mb-1">Seguro Viagem</h4>
                      <p className="text-xs text-muted-foreground">
                        Contrate um seguro viagem para ter tranquilidade durante sua aventura.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
