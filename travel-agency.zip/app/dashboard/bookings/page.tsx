"use client"

import { useState, useEffect } from "react"
import { ClientSidebar } from "@/components/client/client-sidebar"
import { BookingCard } from "@/components/client/booking-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Search, Filter, Calendar, Plus } from "lucide-react"
import Link from "next/link"

export default function ClientBookingsPage() {
  const [bookings, setBookings] = useState([])
  const [filteredBookings, setFilteredBookings] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  useEffect(() => {
    fetchBookings()
  }, [])

  useEffect(() => {
    filterBookings()
  }, [bookings, searchTerm, statusFilter])

  const fetchBookings = async () => {
    try {
      const response = await fetch("/api/bookings.php?action=user_bookings")
      const data = await response.json()

      if (data.success) {
        setBookings(data.data)
      } else {
        setError(data.message)
      }
    } catch (err) {
      setError("Erro ao carregar reservas")
    } finally {
      setLoading(false)
    }
  }

  const filterBookings = () => {
    let filtered = [...bookings]

    // Filtro por termo de busca
    if (searchTerm) {
      filtered = filtered.filter(
        (booking: any) =>
          booking.package_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          booking.destination_name.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Filtro por status
    if (statusFilter !== "all") {
      filtered = filtered.filter((booking: any) => booking.status === statusFilter)
    }

    setFilteredBookings(filtered)
  }

  if (loading) {
    return (
      <div className="flex h-screen">
        <ClientSidebar />
        <div className="flex-1 lg:ml-64 p-8">
          <div className="text-center">
            <p>Carregando reservas...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-muted/50">
      <ClientSidebar />

      <div className="flex-1 lg:ml-64 overflow-auto">
        <div className="p-6 lg:p-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold">Minhas Reservas</h1>
              <p className="text-muted-foreground">Gerencie todas as suas viagens</p>
            </div>
            <Button asChild>
              <Link href="/packages">
                <Plus className="h-4 w-4 mr-2" />
                Nova Reserva
              </Link>
            </Button>
          </div>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Filters */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                Filtros
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por destino ou pacote..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>

                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Status da reserva" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="pending">Pendente</SelectItem>
                    <SelectItem value="confirmed">Confirmada</SelectItem>
                    <SelectItem value="cancelled">Cancelada</SelectItem>
                    <SelectItem value="completed">Concluída</SelectItem>
                  </SelectContent>
                </Select>

                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setStatusFilter("all")
                  }}
                >
                  Limpar Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Bookings List */}
          <div className="space-y-6">
            {filteredBookings.length > 0 ? (
              <>
                <div className="flex items-center justify-between">
                  <p className="text-muted-foreground">{filteredBookings.length} reserva(s) encontrada(s)</p>
                </div>
                {filteredBookings.map((booking: any) => (
                  <BookingCard key={booking.id} booking={booking} />
                ))}
              </>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Nenhuma reserva encontrada</h3>
                  <p className="text-muted-foreground mb-4">
                    {searchTerm || statusFilter !== "all"
                      ? "Tente ajustar os filtros de busca"
                      : "Você ainda não fez nenhuma reserva"}
                  </p>
                  <Button asChild>
                    <Link href="/packages">Explorar Pacotes</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
